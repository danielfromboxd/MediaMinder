import React from "react";
import "./index.css";

export default function Main() {
  return (
    <div className="main-container">
      <div className="rectangle">
        <span className="welcome-message">
          Welcome to
          <br />
          Mediaminder{" "}
        </span>
        <span className="media-tracking">
          For all your media tracking needs — be they books, series, or movies!
        </span>
      </div>
      <div className="sign-up">
        <span className="log-in-1">Log In!</span>
        <div className="email-input">
          <span className="label">Enter your e-mail</span>
          <div className="input">
            <span className="value">name@example.com</span>
          </div>
        </div>
        <div className="password-input">
          <span className="label-2">Enter your password</span>
          <div className="input-3">
            <span className="value-4">Password</span>
          </div>
        </div>
        <div className="log-in-button">
          <span className="log-in-5">Log in</span>
        </div>
        <span className="sign-up-6">Don’t have an account? Sign up!</span>
      </div>
    </div>
  );
}
