import React from "react";
import "./index.css";

export default function Main() {
  return (
    <div className="main-container">
      <div className="rectangle">
        <span className="welcome-message">
          Welcome to
          <br />
          Mediaminder{" "}
        </span>
        <span className="media-tracking">
          For all your media tracking needs — be they books, series, or movies!
        </span>
      </div>
      <div className="sign-up-1">
        <div className="sign-up-2">
          <div className="sign-up-3">
            <span className="title">Sign Up!</span>
          </div>
          <div className="form-contact">
            <div className="name-input">
              <span className="enter-name-label">Enter your name</span>
              <div className="input">
                <span className="value">John Smith</span>
              </div>
            </div>
            <div className="email-input">
              <span className="enter-email-label">Enter your email</span>
              <div className="input-4">
                <span className="value-5">name@example.com</span>
              </div>
            </div>
            <div className="password-input">
              <span className="label">Enter your password</span>
              <div className="input-6">
                <span className="password-input-7">Password</span>
              </div>
            </div>
            <div className="signup-button">
              <span className="signup-btn">Sign up</span>
            </div>
          </div>
        </div>
        <span className="login-link">Already have an account? Log in!</span>
      </div>
    </div>
  );
}
