import React from "react";
import "./index.css";

export default function Main() {
  return (
    <div className="main-container">
      <div className="flex-column">
        <div className="navigation-selector">
          <div className="navigation">
            <span className="navigation-1">Navigation</span>
            <div className="polygon" />
          </div>
          <div className="pages">
            <div className="home">
              <div className="vector" />
              <span className="home-2">Home</span>
            </div>
            <div className="line" />
            <div className="books">
              <div className="vector-3" />
              <span className="books-4">Books</span>
            </div>
            <div className="line-5" />
            <div className="series">
              <div className="vector-6" />
              <span className="series-7">series</span>
            </div>
            <div className="line-8" />
            <div className="movies">
              <div className="vector-9" />
              <span className="movies-a">movies</span>
            </div>
            <div className="line-b" />
            <div className="settings-c">
              <div className="gear" />
              <span className="settings-d">Settings</span>
            </div>
            <div className="line-e" />
            <div className="log-inout">
              <div className="frame">
                <div className="sign-out" />
                <span className="log-out">Log OUT</span>
              </div>
            </div>
            <div className="line-f" />
          </div>
        </div>
        <span className="media-minder">
          MEDIA
          <br />
          MINDER
        </span>
        <div className="logo" />
      </div>
      <div className="flex-column-d">
        <span className="settings-10">settings</span>
        <div className="frame-11">
          <span className="account-management">Account management</span>
          <span className="email-address">Email address:</span>
          <div className="email-input">
            <span className="new-email-address">New email address</span>
          </div>
          <span className="password">Password:</span>
          <div className="password-input">
            <span className="new-password">New password</span>
          </div>
          <div className="update-button">
            <span className="update">Update</span>
          </div>
        </div>
        <div className="frame-12">
          <span className="acknowledgements">Acknowledgements</span>
          <span className="api-disclaimer">
            This product uses the TMDB API but is not endorsed or certified by
            TMDB.
            <br />
            This product likewise uses the OpenLibrary API, but is not endorsed
            or certified by OpenLibrary.
          </span>
        </div>
      </div>
    </div>
  );
}
